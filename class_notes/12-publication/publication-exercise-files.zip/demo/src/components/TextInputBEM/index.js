import './textInput.css';
export {default} from './TextInputBEM';
