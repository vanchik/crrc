export {default} from './Label';
