import React from 'react';
import HelloWorld from 'ps-react/HelloWorld';

/** Custom message */
export default function ExampleHelloWorld() {
  return <HelloWorld message="Pluralsight viewers!" />
}
