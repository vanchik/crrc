import React from 'react';
import EyeIcon from 'ps-react/EyeIcon';

export default function EyeIconExample() {
  return <EyeIcon />;
}
