# Pluralsight React Components

A library of React components created in "Creating Reusable React Components" on Pluralsight.

## Install
```
npm install ps-react
```

## Docs
[Component documentation](http://coryhouse.github.io/ps-react)

## Component Hall of Fame 🎉
Here's a list of components built by your fellow viewers!

Submit a pull request to add your link here... :)
